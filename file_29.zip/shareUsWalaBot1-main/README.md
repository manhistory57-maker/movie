# Message Search Bot

We have to use Bot for Inline Search & Userbot for Searching in Channels. So both Bot & Userbot will work together.

## Installation

<details><summary><b>Deploy to Heroku</b></summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/RoyalKrrishna/shareusWalaBot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>

<details>
  <summary><b>Deploy to Railway</b></summary>
<br/>

<p align="left">
<a href="https://railway.app/deploy?template=https%3A%2F%2Fgithub.com%2FPredatorHackerzZ%2FMessageSearchBot"
">
     <img height="30px" src="https://railway.app/button.svg">
  </a>
</p>
</details>
